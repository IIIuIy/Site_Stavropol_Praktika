/**
 * Яркий Ставрополь — обработка форм и конверсий
 */

(function () {
  'use strict';

  function validateEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  function validatePhone(phone) {
    return phone.replace(/\D/g, '').length >= 10;
  }

  function handleSubmit(form, successMessage) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();

      var emailInput = form.querySelector('[type="email"]');
      var phoneInput = form.querySelector('[type="tel"]');
      var nameInput = form.querySelector('[name="name"]');

      if (emailInput && !validateEmail(emailInput.value.trim())) {
        showToast('Пожалуйста, введите корректный email', 'error');
        emailInput.focus();
        return;
      }

      if (phoneInput && phoneInput.value.trim() && !validatePhone(phoneInput.value)) {
        showToast('Пожалуйста, введите корректный номер телефона', 'error');
        phoneInput.focus();
        return;
      }

      if (nameInput && !nameInput.value.trim()) {
        showToast('Пожалуйста, укажите ваше имя', 'error');
        nameInput.focus();
        return;
      }

      var btn = form.querySelector('[type="submit"]');
      var originalText = btn.textContent;
      btn.textContent = 'Отправка...';
      btn.disabled = true;

      setTimeout(function () {
        btn.textContent = originalText;
        btn.disabled = false;
        form.reset();
        showToast(successMessage);

        var modal = form.closest('.modal-overlay');
        if (modal) {
          modal.classList.remove('open');
          document.body.style.overflow = '';
        }
      }, 1200);
    });
  }

  /* Newsletter forms */
  document.querySelectorAll('.form-newsletter').forEach(function (form) {
    handleSubmit(form, '🎉 Спасибо! Вы подписаны на рассылку «Яркий Ставрополь»');
  });

  /* Event registration */
  document.querySelectorAll('.form-event').forEach(function (form) {
    handleSubmit(form, '🎫 Регистрация подтверждена! Ждём вас на мероприятии');
  });

  /* Tourism booking */
  document.querySelectorAll('.form-tour').forEach(function (form) {
    handleSubmit(form, '✈️ Заявка на тур принята! Мы свяжемся с вами в течение 24 часов');
  });

  /* Contact form */
  document.querySelectorAll('.form-contact').forEach(function (form) {
    handleSubmit(form, '📩 Сообщение отправлено! Мы ответим в ближайшее время');
  });

  /* Business listing request */
  document.querySelectorAll('.form-business').forEach(function (form) {
    handleSubmit(form, '🏢 Заявка на размещение принята! Менеджер свяжется с вами');
  });

})();
