/**
 * Lightbox-галерея
 */
(function () {
  'use strict';

  var lightbox = null;

  document.querySelectorAll('[data-gallery]').forEach(function (gallery) {
    gallery.querySelectorAll('.gallery__item').forEach(function (item, index) {
      item.addEventListener('click', function (e) {
        e.preventDefault();
        openLightbox(gallery, index);
      });
    });
  });

  function openLightbox(gallery, startIndex) {
    var items = gallery.querySelectorAll('.gallery__item');
    var index = startIndex;

    if (!lightbox) {
      lightbox = document.createElement('div');
      lightbox.className = 'lightbox';
      lightbox.innerHTML =
        '<button class="lightbox__close" aria-label="Закрыть">&times;</button>' +
        '<button class="lightbox__nav lightbox__nav--prev" aria-label="Назад">&#8249;</button>' +
        '<button class="lightbox__nav lightbox__nav--next" aria-label="Вперёд">&#8250;</button>' +
        '<div class="lightbox__inner">' +
          '<img class="lightbox__img" src="" alt="">' +
          '<p class="lightbox__caption"></p>' +
        '</div>';
      document.body.appendChild(lightbox);

      lightbox.querySelector('.lightbox__close').addEventListener('click', closeLightbox);
      lightbox.addEventListener('click', function (e) {
        if (e.target === lightbox) closeLightbox();
      });
      document.addEventListener('keydown', onKeydown);
    }

    var imgEl = lightbox.querySelector('.lightbox__img');
    var captionEl = lightbox.querySelector('.lightbox__caption');
    var prevBtn = lightbox.querySelector('.lightbox__nav--prev');
    var nextBtn = lightbox.querySelector('.lightbox__nav--next');

    function show(i) {
      index = (i + items.length) % items.length;
      var item = items[index];
      var img = item.querySelector('img');
      var href = item.getAttribute('href') || (img && img.src);
      var caption = item.getAttribute('data-caption') || (img && img.alt) || '';

      imgEl.src = href;
      imgEl.alt = caption;
      captionEl.textContent = caption;
      lightbox._index = index;
    }

    prevBtn.onclick = function () { show(lightbox._index - 1); };
    nextBtn.onclick = function () { show(lightbox._index + 1); };

    lightbox._show = show;
    lightbox._items = items;

    show(startIndex);
    lightbox.classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function closeLightbox() {
    if (!lightbox) return;
    lightbox.classList.remove('open');
    document.body.style.overflow = '';
  }

  function onKeydown(e) {
    if (!lightbox || !lightbox.classList.contains('open')) return;
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') lightbox._show(lightbox._index - 1);
    if (e.key === 'ArrowRight') lightbox._show(lightbox._index + 1);
  }
})();
