/**
 * Реальные изображения Ставрополя (Wikimedia Commons, CC BY-SA)
 */
var SITE_IMAGES = {
  hero1: {
    src: 'images/Kaz.Stavropol.jpg',
    alt: 'Казанский собор в Ставрополе'
  },
  hero2: {
    src: 'images/caption.jpg',
    alt: 'Фонтан с лебедем, Ставрополь'
  },
  hero3: {
    src: 'images/VID.jpg',
    alt: 'Панорама Ставрополя, октябрь 2018'
  },
  kazan: {
    src: 'images/Kaz.Stavropol.jpg',
    alt: 'Казанский собор — символ Ставрополя'
  },
  fountain: {
    src: 'images/caption.jpg',
    alt: 'Фонтан с лебедем в центре города'
  },
  panorama: {
    src: 'images/VID.jpg',
    alt: 'Вид на Ставрополь с высоты'
  },
  theatre: {
    src: 'images/centr.jpg',
    alt: 'Центральная часть Ставрополя'
  },
  park: {
    src: 'images/fontan.jpg',
    alt: 'Парк и фонтаны Ставрополя'
  },
  lenin: {
    src: 'images/centr.jpg',
    alt: 'Площадь Ленина и центр города'
  },
  museum: {
    src: 'images/History.webp',
    alt: 'Историческая архитектура Ставрополя'
  },
  caucasus: {
    src: 'images/Gora.jpg',
    alt: 'Кавказские горы — вид с предгорий Ставрополья'
  },
  ogDefault: {
    src: 'images/VID.jpg',
    alt: 'Яркий Ставрополь — Моя Родина'
  }
};

(function () {
  'use strict';

  document.querySelectorAll('[data-image]').forEach(function (el) {
    var key = el.getAttribute('data-image');
    var img = SITE_IMAGES[key];
    if (!img) return;

    if (el.tagName === 'IMG') {
      el.src = img.src;
      el.alt = img.alt;
      el.loading = el.getAttribute('loading') || 'lazy';
    } else {
      el.style.backgroundImage = 'linear-gradient(135deg, rgba(26,26,46,0.55), rgba(21,101,192,0.35)), url("' + img.src + '")';
      el.setAttribute('aria-label', img.alt);
    }
  });

  document.querySelectorAll('[data-gallery-src]').forEach(function (el) {
    var key = el.getAttribute('data-gallery-src');
    var img = SITE_IMAGES[key];
    if (!img) return;
    if (el.tagName === 'IMG') {
      el.src = img.src;
      el.alt = img.alt;
    }
    var link = el.closest('a');
    if (link) {
      link.href = img.src;
    }
  });
})();
