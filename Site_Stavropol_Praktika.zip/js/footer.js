/**
 * Единый footer для всех страниц
 */
(function () {
  'use strict';

  var footer = document.getElementById('site-footer');
  if (!footer) return;

  footer.innerHTML =
    '<div class="container">' +
      '<div class="footer__grid">' +
        '<div class="footer__col">' +
          '<div class="footer__brand"><span>Яркий</span> Ставрополь</div>' +
          '<p class="footer__desc">Официальный портал динамичного города на юге России. Моя Родина — место солнца, культуры и возможностей.</p>' +
          '<div class="footer__social">' +
            '<a href="https://vk.com" target="_blank" rel="noopener noreferrer" aria-label="ВКонтакте">VK</a>' +
            '<a href="https://t.me" target="_blank" rel="noopener noreferrer" aria-label="Telegram">TG</a>' +
            '<a href="https://youtube.com" target="_blank" rel="noopener noreferrer" aria-label="YouTube">YT</a>' +
          '</div>' +
        '</div>' +
        '<div class="footer__col">' +
          '<h4 class="footer__heading">Навигация</h4>' +
          '<ul class="footer__links">' +
            '<li><a href="index.html">Главная</a></li>' +
            '<li><a href="about.html">О городе</a></li>' +
            '<li><a href="attractions.html">Достопримечательности</a></li>' +
            '<li><a href="culture.html">Культура &amp; События</a></li>' +
            '<li><a href="tourism.html">Туризм</a></li>' +
            '<li><a href="contact.html">Контакты</a></li>' +
          '</ul>' +
        '</div>' +
        '<div class="footer__col">' +
          '<h4 class="footer__heading">Достопримечательности</h4>' +
          '<ul class="footer__links">' +
            '<li><a href="attractions.html">Казанский собор</a></li>' +
            '<li><a href="attractions.html">Парк Победы</a></li>' +
            '<li><a href="attractions.html">Площадь Ленина</a></li>' +
            '<li><a href="attractions.html">Краеведческий музей</a></li>' +
            '<li><a href="attractions.html">Кавказские предгорья</a></li>' +
          '</ul>' +
        '</div>' +
        '<div class="footer__col">' +
          '<h4 class="footer__heading">Для бизнеса</h4>' +
          '<ul class="footer__links">' +
            '<li><a href="business.html">Справочник компаний</a></li>' +
            '<li><a href="business.html#add">Разместить компанию</a></li>' +
            '<li><a href="contact.html">Реклама на сайте</a></li>' +
            '<li><a href="tourism.html">Партнёрство в туризме</a></li>' +
          '</ul>' +
        '</div>' +
        '<div class="footer__col">' +
          '<h4 class="footer__heading">Контакты</h4>' +
          '<ul class="footer__links">' +
            '<li>355000, г. Ставрополь,<br>ул. Ленина, 1</li>' +
            '<li><a href="tel:+78652222222">+7 (8652) 22-22-22</a></li>' +
            '<li><a href="mailto:info@yarikystavropol.ru">info@yarikystavropol.ru</a></li>' +
          '</ul>' +
        '</div>' +
      '</div>' +
      '<div class="footer__bottom">' +
        '<span>&copy; 2026 Яркий Ставрополь. Все права защищены.</span>' +
        '<div class="footer__bottom-links">' +
          '<a href="contact.html">Обратная связь</a>' +
          '<a href="#">Политика конфиденциальности</a>' +
          '<span>Моя Родина · Ставропольский край</span>' +
        '</div>' +
      '</div>' +
    '</div>';
})();
