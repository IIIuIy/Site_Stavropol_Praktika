/**
 * Универсальный слайдер (hero, отзывы, галерея)
 */
(function () {
  'use strict';

  document.querySelectorAll('.slider').forEach(function (slider) {
    initSlider(slider);
  });

  function initSlider(slider) {
    var track = slider.querySelector('.slider__track');
    var slides = slider.querySelectorAll('.slider__slide');
    if (!track || slides.length < 2) return;

    var prevBtn = slider.querySelector('.slider__arrow--prev');
    var nextBtn = slider.querySelector('.slider__arrow--next');
    var dotsWrap = slider.querySelector('.slider__dots');
    var isCards = slider.classList.contains('slider--cards');
    var current = 0;
    var autoplayMs = parseInt(slider.getAttribute('data-autoplay'), 10) || 0;
    var timer = null;
    var dots = [];

    if (dotsWrap) {
      slides.forEach(function (_, i) {
        var dot = document.createElement('button');
        dot.className = 'slider__dot' + (i === 0 ? ' active' : '');
        dot.type = 'button';
        dot.setAttribute('aria-label', 'Слайд ' + (i + 1));
        dot.addEventListener('click', function () { goTo(i); });
        dotsWrap.appendChild(dot);
        dots.push(dot);
      });
    }

    function goTo(index) {
      if (!isCards && slides[current]) slides[current].classList.remove('active');
      if (dots[current]) dots[current].classList.remove('active');

      current = (index + slides.length) % slides.length;

      if (!isCards && slides[current]) slides[current].classList.add('active');
      if (dots[current]) dots[current].classList.add('active');

      if (isCards) {
        track.style.transform = 'translateX(-' + (current * 100) + '%)';
      }

      resetAutoplay();
    }

    function next() { goTo(current + 1); }
    function prev() { goTo(current - 1); }

    if (nextBtn) nextBtn.addEventListener('click', next);
    if (prevBtn) prevBtn.addEventListener('click', prev);

    slider.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowRight') next();
      if (e.key === 'ArrowLeft') prev();
    });

    var touchStartX = 0;
    slider.addEventListener('touchstart', function (e) {
      touchStartX = e.changedTouches[0].screenX;
    }, { passive: true });

    slider.addEventListener('touchend', function (e) {
      var diff = e.changedTouches[0].screenX - touchStartX;
      if (Math.abs(diff) > 50) {
        diff < 0 ? next() : prev();
      }
    }, { passive: true });

    function resetAutoplay() {
      if (!autoplayMs) return;
      clearInterval(timer);
      timer = setInterval(next, autoplayMs);
    }

    if (autoplayMs) {
      resetAutoplay();
      slider.addEventListener('mouseenter', function () { clearInterval(timer); });
      slider.addEventListener('mouseleave', resetAutoplay);
    }

    slides[0].classList.add('active');
  }
})();
